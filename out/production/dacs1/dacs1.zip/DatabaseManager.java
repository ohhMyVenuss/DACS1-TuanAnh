import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {

    private static final String URL = "jdbc:mysql://localhost:3306/diary_app"; // Thay your_database_name bằng tên database của bạn
    private static final String USER = "root"; // Thay your_username bằng username database của bạn
    private static final String PASSWORD = ""; // Thay your_password bằng password database của bạn

    private static int currentUserId = -1; // Store ID of the logged-in user

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to validate user credentials
    public static int validateUser(String username, String password) {
        String query = "SELECT id FROM users WHERE username = ? AND password = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password); // **WARNING: Storing passwords in plain text is insecure. Consider using password hashing.**
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                currentUserId = rs.getInt("id"); // Store user ID
                return currentUserId;
            } else {
                currentUserId = -1; // Reset user ID
                return -1; // User not found or credentials incorrect
            }
        } catch (SQLException e) {
            e.printStackTrace();
            currentUserId = -1; // Reset user ID on error
            return -1; // Error occurred
        }
    }

    // Method to add a new user
    public static boolean addUser(String username, String password, String email, String address, String phone) {
        String query = "INSERT INTO users (username, password, email, address, phone) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password); // **WARNING: Storing passwords in plain text is insecure. Consider using password hashing.**
            stmt.setString(3, email);
            stmt.setString(4, address);
            stmt.setString(5, phone);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Getter for current user ID
    public static int getCurrentUserId() {
        return currentUserId;
    }

    // Method to get diary entries by user ID
    public static List<DiaryEntry> getDiaryEntriesByUserId(int userId) {
        List<DiaryEntry> entries = new ArrayList<>();
        String query = "SELECT id, title, content, created_at, image_path FROM diary_entries WHERE user_id = ? ORDER BY created_at DESC";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String date = rs.getString("created_at");
                String imagePath = rs.getString("image_path");
                // Fetch tagged user IDs for this entry
                List<Integer> taggedUserIds = getTaggedUserIdsForEntry(id);
                entries.add(new DiaryEntry(id, title, content, date, imagePath, taggedUserIds));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entries;
    }

    // Method to delete a diary entry by ID
    public static boolean deleteDiaryEntry(int diaryId) {
        String query = "DELETE FROM diary_entries WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, diaryId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Return true if at least one row was deleted
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to update an existing diary entry by ID
    public static boolean updateDiaryEntry(int diaryId, String title, String content, String imagePath, List<Integer> taggedUserIds) {
        String updateEntryQuery = "UPDATE diary_entries SET title = ?, content = ?, image_path = ? WHERE id = ?";

        Connection conn = null;
        PreparedStatement updateEntryStmt = null;

        try {
            conn = getConnection();
            conn.setAutoCommit(false); // Start transaction

            // Update diary entry details
            updateEntryStmt = conn.prepareStatement(updateEntryQuery);
            updateEntryStmt.setString(1, title);
            updateEntryStmt.setString(2, content);
            updateEntryStmt.setString(3, imagePath);
            updateEntryStmt.setInt(4, diaryId);
            int rowsAffected = updateEntryStmt.executeUpdate();

            if (rowsAffected == 0) {
                conn.rollback(); // Rollback if diary entry update failed
                return false;
            }

            // Update tagged users: delete existing and insert new ones
            if (!deleteTaggedUsersForEntry(diaryId)) {
                conn.rollback(); // Rollback if deleting tags failed
                return false;
            }
            if (!addTaggedUsersForEntry(diaryId, taggedUserIds)) {
                 conn.rollback(); // Rollback if adding new tags failed
                 return false;
            }

            conn.commit(); // Commit transaction
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            closeConnection(conn);
            try { if (updateEntryStmt != null) updateEntryStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    // Modified method to add a new diary entry with tagged users
    public static boolean addDiaryEntry(int userId, String title, String content, String date, String imagePath, List<Integer> taggedUserIds) {
        String insertEntryQuery = "INSERT INTO diary_entries (user_id, title, content, created_at, image_path) VALUES (?, ?, ?, ?, ?)";
        String insertTaggedUserQuery = "INSERT INTO diary_entry_tagged_users (diary_entry_id, user_id) VALUES (?, ?)";
        
        Connection conn = null;
        PreparedStatement insertEntryStmt = null;
        PreparedStatement insertTaggedUserStmt = null;
        ResultSet rs = null;
        
        try {
            conn = getConnection();
            conn.setAutoCommit(false); // Start transaction
            
            // Insert diary entry
            insertEntryStmt = conn.prepareStatement(insertEntryQuery, PreparedStatement.RETURN_GENERATED_KEYS);
            insertEntryStmt.setInt(1, userId);
            insertEntryStmt.setString(2, title);
            insertEntryStmt.setString(3, content);
            insertEntryStmt.setString(4, date);
            insertEntryStmt.setString(5, imagePath);
            int rowsAffected = insertEntryStmt.executeUpdate();
            
            if (rowsAffected == 0) {
                conn.rollback(); // Rollback if diary entry insertion failed
                return false;
            }
            
            // Get the generated diary entry ID
            rs = insertEntryStmt.getGeneratedKeys();
            int diaryEntryId = -1;
            if (rs.next()) {
                diaryEntryId = rs.getInt(1);
            } else {
                conn.rollback(); // Rollback if failed to get generated key
                return false;
            }
            
            // Insert tagged users
            if (taggedUserIds != null && !taggedUserIds.isEmpty()) {
                insertTaggedUserStmt = conn.prepareStatement(insertTaggedUserQuery);
                for (Integer taggedUserId : taggedUserIds) {
                    insertTaggedUserStmt.setInt(1, diaryEntryId);
                    insertTaggedUserStmt.setInt(2, taggedUserId);
                    insertTaggedUserStmt.addBatch(); // Add to batch
                }
                insertTaggedUserStmt.executeBatch(); // Execute batch insert
            }
            
            conn.commit(); // Commit transaction
            return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            closeConnection(conn);
            try { if (insertEntryStmt != null) insertEntryStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (insertTaggedUserStmt != null) insertTaggedUserStmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    // Helper method to get tagged user IDs for a diary entry
    private static List<Integer> getTaggedUserIdsForEntry(int diaryEntryId) {
        List<Integer> taggedUserIds = new ArrayList<>();
        String query = "SELECT user_id FROM diary_entry_tagged_users WHERE diary_entry_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, diaryEntryId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                taggedUserIds.add(rs.getInt("user_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return taggedUserIds;
    }

    // Method to get shared diary entries (entries owned by user or where user is tagged)
    public static List<DiaryEntry> getSharedDiaryEntries(int userId) {
        List<DiaryEntry> entries = new ArrayList<>();
        String query = "SELECT DISTINCT de.id, de.title, de.content, de.created_at, de.image_path " +
                      "FROM diary_entries de " +
                      "LEFT JOIN diary_entry_tagged_users detu ON de.id = detu.diary_entry_id " +
                      "WHERE detu.user_id = ? " + // Lấy nhật ký mà người dùng được tag
                      "   OR (de.user_id = ? AND EXISTS (SELECT 1 FROM diary_entry_tagged_users sub_detu WHERE sub_detu.diary_entry_id = de.id)) " + // Hoặc nhật ký do người dùng viết VÀ có tag bất kỳ ai
                      "ORDER BY de.created_at DESC";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String date = rs.getString("created_at");
                String imagePath = rs.getString("image_path");
                // Fetch tagged user IDs for this entry
                List<Integer> taggedUserIds = getTaggedUserIdsForEntry(id);
                entries.add(new DiaryEntry(id, title, content, date, imagePath, taggedUserIds));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entries;
    }

    // Method to get username by user ID
    public static String getUsernameById(int userId) {
        String query = "SELECT username FROM users WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("username");
            } else {
                return ""; // Return empty string if user not found
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return ""; // Return empty string on error
        }
    }

    // Method to get list of friends for a user
    public static List<Friend> getFriendsList(int userId) {
        List<Friend> friends = new ArrayList<>();
        String query = "SELECT f.id, f.friend_id, u.username, u.email, u.address, u.phone " +
                      "FROM friends f " +
                      "JOIN users u ON f.friend_id = u.id " +
                      "WHERE f.user_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int friendId = rs.getInt("friend_id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String address = rs.getString("address");
                String phone = rs.getString("phone");
                friends.add(new Friend(id, friendId, username, email, address, phone));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return friends;
    }

    // Method to send a friend request
    public static boolean sendFriendRequest(int senderId, int receiverId) {
        // Check if they are already friends
        if (isFriendshipExists(senderId, receiverId)) {
            return false;
        }
        
        // Check if a request already exists
        String checkQuery = "SELECT COUNT(*) FROM friend_requests WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(checkQuery)) {
            stmt.setInt(1, senderId);
            stmt.setInt(2, receiverId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return false; // Request already exists
            }
            
            // Send new request
            String insertQuery = "INSERT INTO friend_requests (sender_id, receiver_id, status, created_at) VALUES (?, ?, 'pending', NOW())";
            try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                insertStmt.setInt(1, senderId);
                insertStmt.setInt(2, receiverId);
                int rowsAffected = insertStmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to get received friend requests
    public static List<FriendRequest> getReceivedFriendRequests(int userId) {
        List<FriendRequest> requests = new ArrayList<>();
        String query = "SELECT fr.id, fr.sender_id, fr.receiver_id, fr.status, fr.created_at, u.username, u.email " +
                      "FROM friend_requests fr " +
                      "JOIN users u ON fr.sender_id = u.id " +
                      "WHERE fr.receiver_id = ? AND fr.status = 'pending' " +
                      "ORDER BY fr.created_at DESC";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int senderId = rs.getInt("sender_id");
                int receiverId = rs.getInt("receiver_id");
                String status = rs.getString("status");
                String createdAt = rs.getString("created_at");
                String senderUsername = rs.getString("username");
                String senderEmail = rs.getString("email");
                requests.add(new FriendRequest(id, senderId, receiverId, status, createdAt, senderUsername, senderEmail));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return requests;
    }

    // Method to accept a friend request
    public static boolean acceptFriendRequest(int requestId) {
        String getRequestQuery = "SELECT sender_id, receiver_id FROM friend_requests WHERE id = ? AND status = 'pending'";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(getRequestQuery)) {
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int senderId = rs.getInt("sender_id");
                int receiverId = rs.getInt("receiver_id");
                
                // Start transaction
                conn.setAutoCommit(false);
                try {
                    // Add friendship in both directions
                    String addFriendQuery = "INSERT INTO friends (user_id, friend_id) VALUES (?, ?), (?, ?)";
                    try (PreparedStatement addStmt = conn.prepareStatement(addFriendQuery)) {
                        addStmt.setInt(1, senderId);
                        addStmt.setInt(2, receiverId);
                        addStmt.setInt(3, receiverId);
                        addStmt.setInt(4, senderId);
                        addStmt.executeUpdate();
                    }
                    
                    // Update request status
                    String updateQuery = "UPDATE friend_requests SET status = 'accepted' WHERE id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                        updateStmt.setInt(1, requestId);
                        updateStmt.executeUpdate();
                    }
                    
                    conn.commit();
                    return true;
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to reject a friend request
    public static boolean rejectFriendRequest(int requestId) {
        String query = "UPDATE friend_requests SET status = 'rejected' WHERE id = ? AND status = 'pending'";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, requestId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Modified method to add a friend (now sends a friend request instead)
    public static boolean addFriend(int userId, String friendUsername) {
        // First get the friend's ID from username
        String getFriendIdQuery = "SELECT id FROM users WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(getFriendIdQuery)) {
            stmt.setString(1, friendUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int friendId = rs.getInt("id");
                // Send friend request instead of adding directly
                return sendFriendRequest(userId, friendId);
            }
            return false; // Friend not found
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to remove a friend
    public static boolean removeFriend(int userId, int friendId) {
        String query = "DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, friendId);
            stmt.setInt(3, friendId);
            stmt.setInt(4, userId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to check if friendship exists
    private static boolean isFriendshipExists(int userId, int friendId) {
        String query = "SELECT COUNT(*) FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, friendId);
            stmt.setInt(3, friendId);
            stmt.setInt(4, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to get potential friends (users who are not friends yet)
    public static List<Friend> getPotentialFriends(int userId, String searchQuery) {
        List<Friend> potentialFriends = new ArrayList<>();
        String query = "SELECT u.id, u.username, u.email, u.address, u.phone " +
                      "FROM users u " +
                      "WHERE u.id != ? " + // Not the current user
                      "AND u.username != 'admin' " + // Not admin
                      "AND u.id NOT IN ( " + // Not already friends
                      "    SELECT friend_id FROM friends WHERE user_id = ? " +
                      "    UNION " +
                      "    SELECT user_id FROM friends WHERE friend_id = ? " +
                      ") " +
                      "AND u.username LIKE ? " + // Search by username
                      "ORDER BY u.username";
        
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            stmt.setInt(3, userId);
            stmt.setString(4, "%" + searchQuery + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String address = rs.getString("address");
                String phone = rs.getString("phone");
                potentialFriends.add(new Friend(0, id, username, email, address, phone));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return potentialFriends;
    }

    // Method to delete tagged users for a diary entry
    public static boolean deleteTaggedUsersForEntry(int diaryEntryId) {
        String query = "DELETE FROM diary_entry_tagged_users WHERE diary_entry_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, diaryEntryId);
            int rowsAffected = stmt.executeUpdate();
            // Return true even if no rows were affected (means there were no tags to delete)
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to add tagged users for a diary entry
    private static boolean addTaggedUsersForEntry(int diaryId, List<Integer> taggedUserIds) {
        if (taggedUserIds == null || taggedUserIds.isEmpty()) {
            System.out.println("No tagged users to add");
            return true;
        }

        String insertTagQuery = "INSERT INTO diary_tagged_users (diary_id, user_id) VALUES (?, ?)";
        System.out.println("Adding tagged users for diary " + diaryId + ": " + taggedUserIds);

        try (Connection conn = getConnection();
             PreparedStatement insertTagStmt = conn.prepareStatement(insertTagQuery)) {

            for (Integer userId : taggedUserIds) {
                insertTagStmt.setInt(1, diaryId);
                insertTagStmt.setInt(2, userId);
                int result = insertTagStmt.executeUpdate();
                System.out.println("Added tag for user " + userId + ": " + (result > 0 ? "success" : "failed"));
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error adding tagged users: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
} 