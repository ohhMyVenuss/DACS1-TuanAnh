import java.util.List;
import java.util.ArrayList;

public class DiaryEntry {
    int id;
    String title, content, date, imagePath;
    private List<Integer> taggedUserIds; // Field to store tagged friend IDs

    public DiaryEntry(int id, String t, String c, String d, String img) {
        this.id = id;
        title = t; content = c; date = d; imagePath = img;
        this.taggedUserIds = new ArrayList<>(); // Initialize the list
    }
    
    // Constructor including tagged user IDs
    public DiaryEntry(int id, String t, String c, String d, String img, List<Integer> taggedUserIds) {
        this.id = id;
        title = t; content = c; date = d; imagePath = img;
        this.taggedUserIds = taggedUserIds != null ? new ArrayList<>(taggedUserIds) : new ArrayList<>();
    }

    // Add getters if needed by other classes
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getDate() { return date; }
    public String getImagePath() { return imagePath; }

    // Getter for tagged user IDs
    public List<Integer> getTaggedUserIds() {
        return taggedUserIds;
    }

    // Setter for tagged user IDs (if needed, though constructor is preferred for initial setting)
    public void setTaggedUserIds(List<Integer> taggedUserIds) {
        this.taggedUserIds = taggedUserIds != null ? new ArrayList<>(taggedUserIds) : new ArrayList<>();
    }
} 