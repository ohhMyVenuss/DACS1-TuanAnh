import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontPosture;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.animation.ScaleTransition;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.scene.shape.Circle;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.Stop;
import javafx.scene.paint.Paint;
import javafx.stage.FileChooser;
import java.io.File;

import java.util.ArrayList;
import java.util.List;
import javax.swing.SwingUtilities;
import javafx.geometry.Orientation;

public class DiaryMainView extends StackPane {
    private VBox mainBox;
    private HBox topBar;
    private HBox menuBar;
    private Label headerLabel;
    private VBox diaryListBox;
    private ScrollPane scrollPane;
    private List<DiaryEntry> diaryEntries;
    private List<DiaryEntry> sharedEntries;
    private String currentTab = "Nhật ký của tôi";
    private Button fabBtn;
    private List<Button> menuButtons = new ArrayList<>();
    private String currentTheme = "light"; // "light" hoặc "dark"

    public DiaryMainView() {
        setPrefSize(1200, 800);
        mainBox = new VBox();
        mainBox.setSpacing(0);
        mainBox.setPrefSize(1200, 800);
        mainBox.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #232136, #45475a);");

        createTopBar();
        createMenuBar();
        createHeader();
        createDiaryLists();

        mainBox.getChildren().addAll(topBar, menuBar, headerLabel, scrollPane);
        getChildren().add(mainBox);

        createFloatingAddButton();
        updateTab("Nhật ký của tôi");

        // Update the mainBox style after setting the initial tab
        if (currentTheme.equals("light")) {
            mainBox.setStyle("-fx-background-color: linear-gradient(to right, #e0e7ff, #c7d2fe, #a5b4fc);");
        } else {
            mainBox.setStyle("-fx-background-color: linear-gradient(to right, #232136, #393552, #45475a);");
        }

        // Ensure main window is centered when this view is shown
        javafx.application.Platform.runLater(() -> {
            Stage stage = (Stage) getScene().getWindow();
            if (stage != null) stage.centerOnScreen();
        });
    }

    private void createTopBar() {
        topBar = new HBox();
        topBar.setPadding(new Insets(12, 32, 12, 32));
        topBar.setSpacing(16);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color: transparent;");

        ImageView avatar = new ImageView(new Image("file:D:/dacs1/res/avatar.png"));
        avatar.setFitWidth(36);
        avatar.setFitHeight(36);

        // Get and display the logged-in username
        String loggedInUsername = "User"; // Default text
        int currentUserId = DatabaseManager.getCurrentUserId();
        if (currentUserId != -1) {
            String username = DatabaseManager.getUsernameById(currentUserId);
            if (username != null && !username.isEmpty()) {
                loggedInUsername = username;
            }
        }

        MenuButton userMenu = new MenuButton(loggedInUsername + " ▼");
        userMenu.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        userMenu.setTextFill(Color.web("#bfaee0"));
        MenuItem rename = new MenuItem("Đổi tên");
        MenuItem changePass = new MenuItem("Đổi mật khẩu");
        MenuItem logout = new MenuItem("Đăng xuất");
        userMenu.getItems().addAll(rename, changePass, new SeparatorMenuItem(), logout);
        // Đổi tên
        rename.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog(userMenu.getText().replace(" ▼", ""));
            dialog.setTitle("Đổi tên");
            dialog.setHeaderText("Nhập tên mới:");
            dialog.setContentText("Tên:");
            dialog.showAndWait().ifPresent(newName -> {
                if (!newName.trim().isEmpty()) {
                    userMenu.setText(newName + " ▼");
                }
            });
        });
        // Đổi mật khẩu
        changePass.setOnAction(e -> {
            Dialog<String> dialog = new Dialog<>();
            dialog.setTitle("Đổi mật khẩu");
            dialog.setHeaderText("Nhập mật khẩu mới:");
            PasswordField passField = new PasswordField();
            dialog.getDialogPane().setContent(passField);
            dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
            dialog.setResultConverter(btn -> btn == ButtonType.OK ? passField.getText() : null);
            dialog.showAndWait();
        });
        // Đăng xuất
        logout.setOnAction(e -> {
            // Đóng cửa sổ hiện tại và chuyển về LoginView (JavaFX)
            Stage currentStage = (Stage) getScene().getWindow();
            LoginView loginView = new LoginView(currentStage);
            Scene loginScene = new Scene(loginView, 400, 500);
            currentStage.setScene(loginScene);
            currentStage.setTitle("Login");
            currentStage.show();
            javafx.application.Platform.runLater(() -> currentStage.centerOnScreen());
        });
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        topBar.getChildren().addAll(avatar, userMenu, spacer);
    }

    private void createMenuBar() {
        menuBar = new HBox();
        menuBar.setSpacing(0);
        menuBar.setAlignment(Pos.CENTER_LEFT);
        menuBar.setStyle("-fx-background-color: #ede9fe; -fx-padding: 0 40 0 40;");
        menuBar.setPrefHeight(56);
        String[][] menus = {
            {"Nhật ký của tôi", "diary.png"},
            {"Nhật ký được chia sẻ", "shared.png"},
            {"Bạn bè", "friends.png"},
            {"Cài đặt", "settings.png"}
        };
        for (int i = 0; i < menus.length; i++) {
            Button btn = createMenuButton(menus[i][0], menus[i][1]);
            menuButtons.add(btn);
            menuBar.getChildren().add(btn);
            if (i < menus.length - 1) {
                Separator sep = new Separator();
                sep.setOrientation(Orientation.VERTICAL);
                sep.setPrefHeight(32);
                sep.setStyle("-fx-background-color: radial-gradient(center 50% 50%, radius 100%, #232136, #000000); -fx-padding: 0 0 0 0; -fx-pref-width: 1px;");
                menuBar.getChildren().add(sep);
            }
        }
    }

    private Button createMenuButton(String text, String iconFile) {
        Button btn = new Button(text);
        btn.setFont(Font.font("Arial", FontWeight.BOLD, 17));
        btn.setTextFill(Color.web("#6d28d9"));
        // Base style for menu buttons
        btn.setStyle(
            "-fx-background-color: transparent; " +
            "-fx-padding: 0 32 0 32; " +
            "-fx-font-weight: bold; " +
            "-fx-font-size: 17px;" +
            "-fx-min-width: 150px; " + // Set minimum width
            "-fx-pref-width: 150px; " + // Set preferred width
            "-fx-min-height: 56px; " + // Set minimum height
            "-fx-pref-height: 56px;" // Set preferred height
        );

        // Remove hover effects that change size
        btn.setOnMouseEntered(e -> {
             btn.setStyle(
                 "-fx-background-color: #c7d2fe; " +
                 "-fx-padding: 0 32 0 32; " +
                 "-fx-text-fill: #312e81; " +
                 "-fx-font-weight: bold; " +
                 "-fx-font-size: 17px;" +
                 "-fx-min-width: 150px; " +
                 "-fx-pref-width: 150px; " +
                 "-fx-min-height: 56px; " +
                 "-fx-pref-height: 56px;" + 
                 "-fx-border-color: radial-gradient(center 50% 50%, radius 100%, #232136, #000000);" + // Radiant black border
                 "-fx-border-width: 0 0 2 0;" // Bottom border
             );
        });
        btn.setOnMouseExited(e -> {
             if (currentTab.equals(text)) {
                 btn.setStyle(
                     "-fx-background-color: #c7d2fe; " +
                     "-fx-padding: 0 32 0 32; " +
                     "-fx-text-fill: #6d28d9; " +
                     "-fx-font-weight: bold; " +
                     "-fx-font-size: 17px;" +
                     "-fx-min-width: 150px; " +
                     "-fx-pref-width: 150px; " +
                     "-fx-min-height: 56px; " +
                     "-fx-pref-height: 56px;" + 
                     "-fx-border-color: radial-gradient(center 50% 50%, radius 100%, #232136, #000000);" + // Radiant black border
                     "-fx-border-width: 0 0 2 0;" // Bottom border
                 );
             } else {
                 btn.setStyle(
                     "-fx-background-color: transparent; " +
                     "-fx-padding: 0 32 0 32; " +
                     "-fx-text-weight: bold; " + // Corrected property name
                     "-fx-font-size: 17px;" +
                     "-fx-min-width: 150px; " +
                     "-fx-pref-width: 150px; " +
                     "-fx-min-height: 56px; " +
                     "-fx-pref-height: 56px;" // No border for non-selected
                 );
             }
        });

        btn.setPrefHeight(56); // Redundant, but keep for safety
        btn.setAlignment(Pos.CENTER);
        btn.setGraphic(new ImageView(new Image("file:D:/dacs1/res/" + iconFile, 24, 24, true, true)));
        btn.setContentDisplay(ContentDisplay.LEFT);
        btn.setOnAction(e -> updateTab(text));
        return btn;
    }

    private void createHeader() {
        headerLabel = new Label();
        headerLabel.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 34));
        headerLabel.setPadding(new Insets(28, 0, 18, 40));
        updateHeaderGradient();
    }

    private void updateHeaderGradient() {
        if (currentTheme.equals("light")) {
            // Gradient đen-xám cho chữ
            headerLabel.setTextFill(new LinearGradient(
                0, 0, 1, 0, true, CycleMethod.NO_CYCLE,
                new Stop[]{
                    new Stop(0, Color.web("#232136")),
                    new Stop(1, Color.web("#45475a"))
                }
            ));
        } else {
            // Gradient trắng-xám cho chữ
            headerLabel.setTextFill(new LinearGradient(
                0, 0, 1, 0, true, CycleMethod.NO_CYCLE,
                new Stop[]{
                    new Stop(0, Color.web("#f3f4f6")),
                    new Stop(1, Color.web("#e5e7eb"))
                }
            ));
        }
    }

    private void createDiaryLists() {
        // Fetch diary entries from the database for the current user
        diaryEntries = DatabaseManager.getDiaryEntriesByUserId(DatabaseManager.getCurrentUserId());

        sharedEntries = new ArrayList<>();
        //sharedEntries.add(new DiaryEntry("Bạn được tag", "Bạn đã được tag trong một nhật ký...", "2024-03-18", null)); // Example shared entry

        diaryListBox = new VBox(22);
        diaryListBox.setPadding(new Insets(0, 40, 40, 40));
        diaryListBox.setAlignment(Pos.TOP_CENTER);

        scrollPane = new ScrollPane(diaryListBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        VBox.setVgrow(scrollPane, Priority.ALWAYS);
    }

    private Node createDiaryCard(DiaryEntry entry) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(18, 24, 18, 24));
        card.setStyle(currentTheme.equals("light")
            ? "-fx-background-color: #e5e7eb; -fx-background-radius: 16; -fx-effect: dropshadow(gaussian, #a5b4fc44, 7, 0.12, 0, 2);"
            : "-fx-background-color: radial-gradient(center 50% 50%, radius 100%, #45475a, #232136); -fx-background-radius: 16; -fx-effect: dropshadow(gaussian, #6d28d988, 9, 0.18, 0, 2);");
        card.setMaxWidth(600);
        card.setMinWidth(350);
        card.setAlignment(Pos.TOP_LEFT);

        HBox top = new HBox();
        Label title = new Label(entry.title);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        title.setTextFill(Color.web("#312e81"));
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label date = new Label(entry.date);
        date.setFont(Font.font("Arial", FontWeight.NORMAL, 13));
        date.setTextFill(Color.web("#6d28d9"));
        top.getChildren().addAll(title, spacer, date);

        VBox contentBox = new VBox(8);
        if (entry.imagePath != null && !entry.imagePath.isEmpty()) {
            ImageView img = new ImageView(new Image(entry.imagePath, 150, 0, true, true));
            img.setSmooth(true);
            img.setPreserveRatio(true);
            img.setStyle("-fx-background-radius: 8;");
            contentBox.getChildren().add(img);
        }
        Label content = new Label(entry.content);
        content.setFont(Font.font("Arial", FontWeight.NORMAL, 15));
        content.setTextFill(Color.web("#444"));
        content.setWrapText(true);
        contentBox.getChildren().add(content);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        Button editBtn = new Button("Sửa");
        editBtn.setStyle("-fx-background-color: #a5b4fc; -fx-text-fill: #232136; -fx-background-radius: 8;");
        editBtn.setOnMouseEntered(e -> editBtn.setStyle("-fx-background-color: #818cf8; -fx-text-fill: white; -fx-background-radius: 8;"));
        editBtn.setOnMouseExited(e -> editBtn.setStyle("-fx-background-color: #a5b4fc; -fx-text-fill: #232136; -fx-background-radius: 8;"));
        editBtn.setOnAction(e -> {
            System.out.println("Edit button clicked for entry: " + entry.title);
            showEditDiaryDialog(entry);
        });

        Button deleteBtn = new Button("Xóa");
        deleteBtn.setStyle("-fx-background-color: #fca5a5; -fx-text-fill: #444; -fx-background-radius: 8;");
        deleteBtn.setOnMouseEntered(e -> deleteBtn.setStyle("-fx-background-color: #f87171; -fx-text-fill: white; -fx-background-radius: 8;"));
        deleteBtn.setOnMouseExited(e -> deleteBtn.setStyle("-fx-background-color: #fca5a5; -fx-text-fill: #444; -fx-background-radius: 8;"));
        deleteBtn.setOnAction(e -> {
            System.out.println("Delete button clicked for entry: " + entry.title);
            // Add confirmation dialog
            Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDialog.setTitle("Xác nhận xóa");
            confirmDialog.setHeaderText("Bạn có chắc chắn muốn xóa nhật ký này?");
            confirmDialog.setContentText("Nhật ký: " + entry.title);

            confirmDialog.showAndWait().ifPresent(result -> {
                if (result == ButtonType.OK) {
                    // Call DatabaseManager to delete the entry
                    if (DatabaseManager.deleteDiaryEntry(entry.id)) {
                        // Remove the card from the UI and refresh the list
                        diaryListBox.getChildren().remove(card);
                        diaryEntries.remove(entry); // Also remove from the list in memory
                        Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Đã xóa nhật ký thành công!");
                        successAlert.showAndWait();
                    } else {
                        Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Lỗi khi xóa nhật ký khỏi cơ sở dữ liệu!");
                        errorAlert.showAndWait();
                    }
                }
            });
        });

        buttonBox.getChildren().addAll(editBtn, deleteBtn);

        card.getChildren().addAll(top, contentBox, buttonBox);

        // Add click handler to show detailed view
        card.setOnMouseClicked(event -> {
            // Prevent opening detail view if click is on edit/delete buttons
            Node target = (Node) event.getTarget();
            if (!(target instanceof Button) || (!((Button) target).getText().equals("Sửa") && !((Button) target).getText().equals("Xóa"))) {
                DiaryDetailView detailView = new DiaryDetailView(entry);
                detailView.show();
            }
        });

        // Hiệu ứng hover (adjusting to new style)
        card.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(180), card);
            st.setToX(1.02); st.setToY(1.02); st.play(); // Slightly less pronounced scale
            card.setStyle(card.getStyle() + (currentTheme.equals("light") ? ";-fx-effect: dropshadow(gaussian, #a5b4fc88, 10, 0.2, 0, 2);" : ";-fx-effect: dropshadow(gaussian, #6d28d9cc, 12, 0.25, 0, 3);")); // Adjusted glow effect
        });
        card.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(180), card);
            st.setToX(1); st.setToY(1); st.play();
            card.setStyle(currentTheme.equals("light")
                ? "-fx-background-color: #e5e7eb; -fx-background-radius: 16; -fx-effect: dropshadow(gaussian, #a5b4fc44, 7, 0.12, 0, 2);"
                : "-fx-background-color: radial-gradient(center 50% 50%, radius 100%, #45475a, #232136); -fx-background-radius: 16; -fx-effect: dropshadow(gaussian, #6d28d988, 9, 0.18, 0, 2);");
        });

        return card;
    }

    private void createFloatingAddButton() {
        fabBtn = new Button("+");
        fabBtn.setFont(Font.font("Arial", FontWeight.BOLD, 32));
        fabBtn.setTextFill(Color.WHITE);
        fabBtn.setStyle(currentTheme.equals("light")
            ? "-fx-background-color: #6d28d9; -fx-background-radius: 50%; -fx-min-width: 64px; -fx-min-height: 64px; -fx-max-width: 64px; -fx-max-height: 64px; -fx-effect: dropshadow(gaussian, #a5b4fc88, 12, 0.3, 0, 2);"
            : "-fx-background-color: #a5b4fc; -fx-background-radius: 50%; -fx-min-width: 64px; -fx-min-height: 64px; -fx-max-width: 64px; -fx-max-height: 64px; -fx-effect: dropshadow(gaussian, #6d28d988, 12, 0.3, 0, 2);");
        fabBtn.setOnAction(e -> showAddDiaryDialog());
        fabBtn.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(120), fabBtn);
            st.setToX(1.12); st.setToY(1.12); st.play();
        });
        fabBtn.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(120), fabBtn);
            st.setToX(1); st.setToY(1); st.play();
        });
        setMargin(fabBtn, new Insets(0, 48, 48, 0));
        StackPane.setAlignment(fabBtn, Pos.BOTTOM_RIGHT);
        getChildren().add(fabBtn);
    }

    private void updateTab(String tab) {
        currentTab = tab;
        // Highlight tab and apply border
        for (Button btn : menuButtons) {
            if (btn.getText().equals(tab)) {
                btn.setStyle(
                    "-fx-background-color: #c7d2fe; " +
                    "-fx-padding: 0 32 0 32; " +
                    "-fx-text-fill: #6d28d9; " +
                    "-fx-font-weight: bold; " +
                    "-fx-font-size: 17px;" +
                    "-fx-min-width: 150px; " +
                    "-fx-pref-width: 150px; " +
                    "-fx-min-height: 56px; " +
                    "-fx-pref-height: 56px;" + 
                    "-fx-border-color: radial-gradient(center 50% 50%, radius 100%, #232136, #000000);" + // Radiant black border
                    "-fx-border-width: 0 0 2 0;" // Bottom border for selected tab
                );
            } else {
                btn.setStyle(
                    "-fx-background-color: transparent; " +
                    "-fx-padding: 0 32 0 32; " +
                    "-fx-text-fill: #6d28d9; " +
                    "-fx-font-weight: bold; " +
                    "-fx-font-size: 17px;" +
                    "-fx-min-width: 150px; " +
                    "-fx-pref-width: 150px; " +
                    "-fx-min-height: 56px; " +
                    "-fx-pref-height: 56px;" // No border for non-selected
                );
            }
        }
        // Đổi tiêu đề và danh sách
        if (tab.equals("Nhật ký của tôi")) {
            headerLabel.setText("Nhật ký của tôi");
            updateHeaderGradient();
            // Reload diary entries from database when switching to this tab
            diaryEntries = DatabaseManager.getDiaryEntriesByUserId(DatabaseManager.getCurrentUserId());
            updateDiaryList(diaryEntries);
            fabBtn.setVisible(true);
        } else if (tab.equals("Nhật ký được chia sẻ")) {
            headerLabel.setText("Nhật ký được chia sẻ");
            updateHeaderGradient();
            sharedEntries = DatabaseManager.getSharedDiaryEntries(DatabaseManager.getCurrentUserId());
            updateDiaryList(sharedEntries);
            fabBtn.setVisible(false);
        } else if (tab.equals("Bạn bè")) {
            headerLabel.setText("Bạn bè");

            VBox friendsContentBox = new VBox(25); // Increased spacing between sections
            friendsContentBox.setPadding(new Insets(30, 40, 40, 40)); // Adjusted padding
            friendsContentBox.setAlignment(Pos.TOP_LEFT);

            // Friend Requests section
            Label requestsLabel = new Label("Lời mời kết bạn");
            requestsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20)); // Slightly larger font
            requestsLabel.setTextFill(Color.web("#312e81"));
            requestsLabel.setPadding(new Insets(0, 0, 5, 0)); // Add padding below title

            // Get received friend requests
            List<FriendRequest> receivedRequests = DatabaseManager.getReceivedFriendRequests(DatabaseManager.getCurrentUserId());

            VBox requestsList = new VBox(15); // Adjusted spacing for list items
            if (receivedRequests.isEmpty()) {
                Label noRequestsLabel = new Label("Không có lời mời kết bạn nào."); // Message when no requests
                noRequestsLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
                noRequestsLabel.setTextFill(Color.web("#6b7280"));
                requestsList.getChildren().add(noRequestsLabel);
                requestsLabel.setVisible(false); // Hide header if no requests
            } else {
                for (FriendRequest request : receivedRequests) {
                    HBox requestCard = createFriendRequestCard(request); // Create a method for this
                    requestsList.getChildren().add(requestCard);
                }
                 requestsLabel.setVisible(true); // Show header if there are requests
            }

            Separator separator1 = new Separator(); // Separator between sections
            separator1.setOrientation(Orientation.HORIZONTAL);
            separator1.setStyle("-fx-background-color: #a5b4fc; -fx-pref-height: 1.5px;");

            // Friends list section
            Label friendsLabel = new Label("Danh sách bạn bè");
            friendsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20)); // Slightly larger font
            friendsLabel.setTextFill(Color.web("#312e81"));
            friendsLabel.setPadding(new Insets(0, 0, 5, 0)); // Add padding below title

            // Get friends list from database
            List<Friend> friends = DatabaseManager.getFriendsList(DatabaseManager.getCurrentUserId());

            VBox friendsList = new VBox(15); // Adjusted spacing for list items
            if (friends.isEmpty()) {
                Label noFriendsLabel = new Label("Bạn chưa có bạn bè nào");
                noFriendsLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
                noFriendsLabel.setTextFill(Color.web("#6b7280"));
                friendsList.getChildren().add(noFriendsLabel);
            } else {
                for (Friend friend : friends) {
                    HBox friendCard = createFriendCard(friend);
                    friendsList.getChildren().add(friendCard);
                }
            }

            Separator separator = new Separator(); // Separator between sections
            separator.setOrientation(Orientation.HORIZONTAL);
            separator.setStyle("-fx-background-color: #a5b4fc; -fx-pref-height: 1.5px;");

            // Other users section (includes search and list)
            Label otherUsersLabel = new Label("Tìm kiếm và thêm bạn"); // Changed label text
            otherUsersLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20)); // Slightly larger font
            otherUsersLabel.setTextFill(Color.web("#312e81"));
            otherUsersLabel.setPadding(new Insets(10, 0, 5, 0)); // Add padding below title

            // Container for search and potential friends list
            VBox searchAndPotentialBox = new VBox(15); // Spacing between search bar and list
            searchAndPotentialBox.setAlignment(Pos.TOP_LEFT);
            VBox.setVgrow(searchAndPotentialBox, Priority.ALWAYS); // Make the container for search/list grow vertically

            // Search box
            HBox searchBox = new HBox(10); // Search bar for finding other users
            searchBox.setAlignment(Pos.CENTER_LEFT);
            TextField searchField = new TextField();
            searchField.setPromptText("Nhập tên người dùng để tìm kiếm..."); // Updated prompt text
            searchField.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
            searchField.setPrefWidth(350); // Increased width
            searchField.setPrefHeight(30); // Explicitly set preferred height
            searchField.setStyle(
                "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-border-color: #a5b4fc;" +
                "-fx-border-width: 1.2;" +
                "-fx-background-color: #fff;"
            );
            searchBox.getChildren().add(searchField); // Add search field to its HBox
            HBox.setHgrow(searchField, Priority.ALWAYS); // Make search field grow horizontally

            VBox potentialFriendsList = new VBox(12); // List for search results
            VBox.setVgrow(potentialFriendsList, Priority.ALWAYS); // Make potential friends list grow vertically

            // Method to update the potential friends list based on search query
            Runnable updatePotentialFriendsList = () -> {
                String searchText = searchField.getText().trim();
                List<Friend> potentialFriends = DatabaseManager.getPotentialFriends(
                    DatabaseManager.getCurrentUserId(),
                    searchText
                );

                potentialFriendsList.getChildren().clear();
                if (potentialFriends.isEmpty()) {
                    Label noResultsLabel = new Label("Không tìm thấy người dùng nào phù hợp."); // Adjusted message
                    noResultsLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
                    noResultsLabel.setTextFill(Color.web("#6b7280"));
                    potentialFriendsList.getChildren().add(noResultsLabel);
                } else {
                    for (Friend user : potentialFriends) {
                        HBox userCard = createPotentialFriendCard(user);
                        potentialFriendsList.getChildren().add(userCard);
                    }
                }
            };

            // Initial load of potential friends (empty search query) and search functionality
            updatePotentialFriendsList.run(); // Load initially with empty search

            searchField.textProperty().addListener((observable, oldValue, newValue) -> {
                updatePotentialFriendsList.run(); // Update list whenever search text changes
            });

            // Add search box and potential friends list to their container
            searchAndPotentialBox.getChildren().addAll(searchBox, potentialFriendsList);

            friendsContentBox.getChildren().addAll(
                requestsLabel,
                requestsList,
                separator1,
                friendsLabel,
                friendsList,
                separator,
                otherUsersLabel,
                searchAndPotentialBox // Add the new container here
            );

            diaryListBox.getChildren().clear();
            diaryListBox.getChildren().add(friendsContentBox);
            fabBtn.setVisible(false);
        } else if (tab.equals("Cài đặt")) {
            headerLabel.setText("Cài đặt");
            VBox settingsBox = new VBox(28);
            settingsBox.setPadding(new Insets(40, 0, 0, 0));
            settingsBox.setAlignment(Pos.TOP_CENTER);

            VBox card = new VBox(24);
            card.setPadding(new Insets(32, 40, 32, 40));
            card.setStyle("-fx-background-color: #f3f4f6; -fx-background-radius: 18; -fx-effect: dropshadow(gaussian, #a5b4fc88, 10, 0.2, 0, 2);");
            card.setMaxWidth(400);
            card.setAlignment(Pos.TOP_CENTER);

            CheckBox notifyCheck = new CheckBox("Bật thông báo");
            notifyCheck.setFont(Font.font("Arial", FontWeight.BOLD, 16));
            notifyCheck.setTextFill(Color.web("#312e81"));

            Button changeThemeBtn = new Button("Đổi giao diện");
            changeThemeBtn.setFont(Font.font("Arial", FontWeight.BOLD, 16));
            changeThemeBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;");
            changeThemeBtn.setOnMouseEntered(e -> changeThemeBtn.setStyle("-fx-background-color: #a5b4fc; -fx-text-fill: #312e81; -fx-background-radius: 10;"));
            changeThemeBtn.setOnMouseExited(e -> changeThemeBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;"));
            changeThemeBtn.setOnAction(e -> {
                if (currentTheme.equals("light")) {
                    currentTheme = "dark";
                    mainBox.setStyle("-fx-background-color: linear-gradient(to right, #232136, #393552, #45475a);");
                } else {
                    currentTheme = "light";
                    mainBox.setStyle("-fx-background-color: linear-gradient(to right, #e0e7ff, #c7d2fe, #a5b4fc);");
                }
                updateTab(currentTab);
            });

            Button changeLangBtn = new Button("Đổi ngôn ngữ");
            changeLangBtn.setFont(Font.font("Arial", FontWeight.BOLD, 16));
            changeLangBtn.setStyle("-fx-background-color: #ede9fe; -fx-text-fill: #6d28d9; -fx-background-radius: 10;");
            changeLangBtn.setOnMouseEntered(e -> changeLangBtn.setStyle("-fx-background-color: #c7d2fe; -fx-text-fill: #312e81; -fx-background-radius: 10;"));
            changeLangBtn.setOnMouseExited(e -> changeLangBtn.setStyle("-fx-background-color: #ede9fe; -fx-text-fill: #6d28d9; -fx-background-radius: 10;"));

            card.getChildren().addAll(notifyCheck, changeThemeBtn, changeLangBtn);
            settingsBox.getChildren().add(card);

            diaryListBox.getChildren().clear();
            diaryListBox.getChildren().add(settingsBox);
            fabBtn.setVisible(false);
        }
        updateHeaderGradient();
    }

    private void updateDiaryList(List<DiaryEntry> list) {
        diaryListBox.getChildren().clear();
        for (DiaryEntry entry : list) {
            diaryListBox.getChildren().add(createDiaryCard(entry));
        }
    }

    private void showAddDiaryDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Thêm nhật ký mới");
        Font handwritingFont = Font.loadFont("file:D:/dacs1/res/IndieFlower.ttf", 20);
        if (handwritingFont == null) {
            handwritingFont = Font.font("Arial", FontWeight.NORMAL, 20);
        }
        VBox box = new VBox(22);
        box.setPadding(new Insets(36, 36, 32, 36));
        box.setAlignment(Pos.CENTER);
        box.setSpacing(18);
        box.setStyle(
            "-fx-background-radius: 22;" +
            "-fx-background-insets: 0;" +
            "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #ede9fe, #c7d2fe);" +
            "-fx-effect: dropshadow(gaussian, #a5b4fc88, 18, 0.3, 0, 4);"
        );
        Label titleLbl = new Label("Thêm nhật ký mới");
        titleLbl.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 26));
        titleLbl.setTextFill(Color.web("#6d28d9"));
        titleLbl.setStyle("-fx-effect: dropshadow(gaussian, #a5b4fc, 8, 0.2, 0, 2);");
        TextField titleField = new TextField();
        titleField.setPromptText("Tiêu đề");
        titleField.setFont(handwritingFont);
        titleField.setPrefWidth(340);
        titleField.setStyle(
            "-fx-background-radius: 12;" +
            "-fx-border-radius: 12;" +
            "-fx-border-color: #a5b4fc;" +
            "-fx-border-width: 1.2;" +
            "-fx-background-color: #fff;"
        );
        TextArea contentArea = new TextArea();
        contentArea.setPromptText("Nội dung");
        contentArea.setFont(handwritingFont);
        contentArea.setPrefWidth(340);
        contentArea.setPrefHeight(180);
        contentArea.setStyle(
            "-fx-background-radius: 12;" +
            "-fx-border-radius: 12;" +
            "-fx-border-color: #a5b4fc;" +
            "-fx-border-width: 1.2;" +
            "-fx-background-color: #fff;"
        );
        ImageView imagePreview = new ImageView();
        imagePreview.setFitWidth(160);
        imagePreview.setFitHeight(120);
        imagePreview.setPreserveRatio(true);
        imagePreview.setVisible(false);
        final String[] imagePath = {null};
        Button attachImgBtn = new Button("🖼️ Đính kèm ảnh");
        attachImgBtn.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        attachImgBtn.setStyle(
            "-fx-background-color: #ede9fe;" +
            "-fx-background-radius: 10;" +
            "-fx-text-fill: #6d28d9;"
        );
        attachImgBtn.setOnMouseEntered(e -> attachImgBtn.setStyle("-fx-background-color: #c7d2fe; -fx-background-radius: 10; -fx-text-fill: #312e81;"));
        attachImgBtn.setOnMouseExited(e -> attachImgBtn.setStyle("-fx-background-color: #ede9fe; -fx-background-radius: 10; -fx-text-fill: #6d28d9;"));
        attachImgBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Chọn ảnh");
            fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
            );
            java.io.File file = fileChooser.showOpenDialog(dialog);
            if (file != null) {
                imagePath[0] = file.toURI().toString();
                Image img = new Image(imagePath[0]);
                imagePreview.setImage(img);
                imagePreview.setVisible(true);
            }
        });
        Button cancelBtn = new Button("Hủy");
        cancelBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        cancelBtn.setStyle("-fx-background-color: #e5e7eb; -fx-text-fill: #6d28d9; -fx-background-radius: 10;");
        cancelBtn.setOnMouseEntered(e -> cancelBtn.setStyle("-fx-background-color: #c7d2fe; -fx-text-fill: #232136; -fx-background-radius: 10;"));
        cancelBtn.setOnMouseExited(e -> cancelBtn.setStyle("-fx-background-color: #e5e7eb; -fx-text-fill: #6d28d9; -fx-background-radius: 10;"));
        cancelBtn.setOnAction(e -> dialog.close());

        Button saveBtn = new Button("Lưu");
        saveBtn.setDefaultButton(true);
        saveBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        saveBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;");
        saveBtn.setOnMouseEntered(e -> saveBtn.setStyle("-fx-background-color: #a5b4fc; -fx-text-fill: #232136; -fx-background-radius: 10;"));
        saveBtn.setOnMouseExited(e -> saveBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;"));

        // Tag Friends Section
        Label tagFriendsLabel = new Label("Tag bạn bè:");
        tagFriendsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        tagFriendsLabel.setTextFill(Color.web("#312e81"));

        VBox taggedFriendsBox = new VBox(8);
        taggedFriendsBox.setPadding(new Insets(0, 0, 12, 0));

        // Fetch and display friends as checkboxes
        List<Friend> friendsList = DatabaseManager.getFriendsList(DatabaseManager.getCurrentUserId());
        List<CheckBox> friendCheckboxes = new ArrayList<>();

        if (friendsList.isEmpty()) {
            Label noFriendsToTagLabel = new Label("Chưa có bạn bè để tag.");
            noFriendsToTagLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
            noFriendsToTagLabel.setTextFill(Color.web("#6b7280"));
            taggedFriendsBox.getChildren().add(noFriendsToTagLabel);
        } else {
            for (Friend friend : friendsList) {
                CheckBox friendCheckBox = new CheckBox(friend.getUsername());
                friendCheckBox.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
                friendCheckBox.setTextFill(Color.web("#444"));
                friendCheckBox.setUserData(friend.getFriendId()); // Store friend ID in UserData
                friendCheckboxes.add(friendCheckBox);
                taggedFriendsBox.getChildren().add(friendCheckBox);
            }
        }

        HBox btnBox = new HBox(14, saveBtn, cancelBtn);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        box.getChildren().addAll(
            titleLbl,
            titleField,
            contentArea,
            attachImgBtn,
            imagePreview,
            tagFriendsLabel,
            taggedFriendsBox,
            btnBox
        );
        Scene scene = new Scene(box);
        // Animation mở dialog
        box.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(320), box);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();

        // MOVE saveBtn.setOnAction HERE
        saveBtn.setOnAction(e -> {
            System.out.println("Save button clicked");
            String title = titleField.getText().trim();
            String content = contentArea.getText().trim();
            String currentImagePath = imagePath[0];

            System.out.println("Title: " + title);
            System.out.println("Content: " + content);
            System.out.println("Image path: " + currentImagePath);

            // Collect tagged user IDs from checkboxes
            List<Integer> taggedUserIds = new ArrayList<>();
            for (CheckBox cb : friendCheckboxes) {
                if (cb.isSelected()) {
                    try {
                        Object userData = cb.getUserData();
                        if (userData instanceof Integer) {
                            taggedUserIds.add((Integer) userData);
                        } else {
                            System.err.println("User data is not an Integer: " + userData);
                        }
                    } catch (Exception ex) {
                        System.err.println("Error processing friend checkbox: " + ex.getMessage());
                    }
                }
            }
            System.out.println("Tagged user IDs: " + taggedUserIds);

            if (title.isEmpty() || content.isEmpty()) {
                System.out.println("Title or content is empty");
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Cảnh báo");
                alert.setHeaderText(null);
                alert.setContentText("Vui lòng nhập đầy đủ tiêu đề và nội dung!");
                alert.showAndWait();
                return;
            }

            try {
                // Get current date in yyyy-MM-dd format
                String currentDate = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ISO_LOCAL_DATE);
                System.out.println("Current date: " + currentDate);
                
                System.out.println("Current user ID: " + DatabaseManager.getCurrentUserId());
                
                // Add diary entry to database
                System.out.println("Attempting to add diary entry...");
                boolean success = DatabaseManager.addDiaryEntry(
                    DatabaseManager.getCurrentUserId(),
                    title,
                    content,
                    currentDate,
                    currentImagePath,
                    taggedUserIds
                );

                System.out.println("Add diary entry result: " + success);

                if (success) {
                    // Refresh the current tab to show new entry
                    updateTab(currentTab);
                    dialog.close();
                    
                    // Show success message
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Thành công");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("Đã thêm nhật ký thành công!");
                    successAlert.showAndWait();
                } else {
                    // This else block should be reachable now
                    throw new Exception("DatabaseManager.addDiaryEntry returned false");
                }
            } catch (Exception ex) {
                System.err.println("Error adding diary entry: " + ex.getMessage());
                ex.printStackTrace();
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Lỗi");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("Lỗi khi thêm nhật ký: " + ex.getMessage());
                errorAlert.showAndWait();
            }
        });

        dialog.setScene(scene);
        javafx.application.Platform.runLater(() -> dialog.centerOnScreen());
        dialog.showAndWait();
    }

    private void showEditDiaryDialog(DiaryEntry entry) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Chỉnh sửa nhật ký");

        Font handwritingFont = Font.loadFont("file:D:/dacs1/res/IndieFlower.ttf", 20);
        if (handwritingFont == null) {
            handwritingFont = Font.font("Arial", FontWeight.NORMAL, 20);
        }

        VBox box = new VBox(22);
        box.setPadding(new Insets(36, 36, 32, 36));
        box.setAlignment(Pos.CENTER);
        box.setSpacing(18);
        box.setStyle(
            "-fx-background-radius: 22;" +
            "-fx-background-insets: 0;" +
            "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #ede9fe, #c7d2fe);" +
            "-fx-effect: dropshadow(gaussian, #a5b4fc88, 18, 0.3, 0, 4);"
        );

        Label titleLbl = new Label("Chỉnh sửa nhật ký");
        titleLbl.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 26));
        titleLbl.setTextFill(Color.web("#6d28d9"));
        titleLbl.setStyle("-fx-effect: dropshadow(gaussian, #a5b4fc, 8, 0.2, 0, 2);");

        TextField titleField = new TextField(entry.title); // Populate with existing title
        titleField.setPromptText("Tiêu đề");
        titleField.setFont(handwritingFont);
        titleField.setPrefWidth(340);
        titleField.setStyle(
            "-fx-background-radius: 12;" +
            "-fx-border-radius: 12;" +
            "-fx-border-color: #a5b4fc;" +
            "-fx-border-width: 1.2;" +
            "-fx-background-color: #fff;"
        );

        TextArea contentArea = new TextArea(entry.content); // Populate with existing content
        contentArea.setPromptText("Nội dung");
        contentArea.setFont(handwritingFont);
        contentArea.setPrefWidth(340);
        contentArea.setPrefHeight(180);
        contentArea.setStyle(
            "-fx-background-radius: 12;" +
            "-fx-border-radius: 12;" +
            "-fx-border-color: #a5b4fc;" +
            "-fx-border-width: 1.2;" +
            "-fx-background-color: #fff;"
        );

        ImageView imagePreview = new ImageView();
        imagePreview.setFitWidth(160);
        imagePreview.setFitHeight(120);
        imagePreview.setPreserveRatio(true);
        final String[] imagePath = {entry.imagePath}; // Store existing image path
        if (imagePath[0] != null && !imagePath[0].isEmpty()) {
             Image img = new Image(imagePath[0]);
             imagePreview.setImage(img);
             imagePreview.setVisible(true);
        } else {
            imagePreview.setVisible(false);
        }

        Button attachImgBtn = new Button("🖼️ Đính kèm ảnh");
        attachImgBtn.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        attachImgBtn.setStyle(
            "-fx-background-color: #ede9fe;" +
            "-fx-background-radius: 10;" +
            "-fx-text-fill: #6d28d9;"
        );
        attachImgBtn.setOnMouseEntered(e -> attachImgBtn.setStyle("-fx-background-color: #c7d2fe; -fx-background-radius: 10; -fx-text-fill: #312e81;"));
        attachImgBtn.setOnMouseExited(e -> attachImgBtn.setStyle("-fx-background-color: #ede9fe; -fx-background-radius: 10; -fx-text-fill: #6d28d9;"));
        attachImgBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Chọn ảnh");
            fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
            );
            java.io.File file = fileChooser.showOpenDialog(dialog);
            if (file != null) {
                imagePath[0] = file.toURI().toString();
                Image img = new Image(imagePath[0]);
                imagePreview.setImage(img);
                imagePreview.setVisible(true);
            }
        });

        Button saveBtn = new Button("Lưu");
        saveBtn.setDefaultButton(true);
        saveBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        saveBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;");
        saveBtn.setOnMouseEntered(e -> saveBtn.setStyle("-fx-background-color: #a5b4fc; -fx-text-fill: #232136; -fx-background-radius: 10;"));
        saveBtn.setOnMouseExited(e -> saveBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;"));

        // Add cancel button definition
        Button cancelBtn = new Button("Hủy");
        cancelBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        cancelBtn.setStyle("-fx-background-color: #e5e7eb; -fx-text-fill: #6d28d9; -fx-background-radius: 10;");
        cancelBtn.setOnMouseEntered(e -> cancelBtn.setStyle("-fx-background-color: #c7d2fe; -fx-text-fill: #232136; -fx-background-radius: 10;"));
        cancelBtn.setOnMouseExited(e -> cancelBtn.setStyle("-fx-background-color: #e5e7eb; -fx-text-fill: #6d28d9; -fx-background-radius: 10;"));
        cancelBtn.setOnAction(e -> dialog.close());

        // Tag Friends Section for Edit Dialog
        Label tagFriendsLabel = new Label("Tag bạn bè:");
        tagFriendsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        tagFriendsLabel.setTextFill(Color.web("#312e81"));

        VBox taggedFriendsBox = new VBox(8);
        taggedFriendsBox.setPadding(new Insets(0, 0, 12, 0));

        // Fetch friends and display as checkboxes, pre-selecting tagged friends
        List<Friend> friendsList = DatabaseManager.getFriendsList(DatabaseManager.getCurrentUserId());
        List<Integer> currentlyTaggedUserIds = entry.getTaggedUserIds(); // Get currently tagged user IDs
        List<CheckBox> friendCheckboxes = new ArrayList<>();

        if (friendsList.isEmpty()) {
            Label noFriendsToTagLabel = new Label("Chưa có bạn bè để tag.");
            noFriendsToTagLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
            noFriendsToTagLabel.setTextFill(Color.web("#6b7280"));
            taggedFriendsBox.getChildren().add(noFriendsToTagLabel);
        } else {
            for (Friend friend : friendsList) {
                CheckBox friendCheckBox = new CheckBox(friend.getUsername());
                friendCheckBox.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
                friendCheckBox.setTextFill(Color.web("#444"));
                friendCheckBox.setUserData(friend.getFriendId()); // Store friend ID

                // Pre-select if this friend is currently tagged
                if (currentlyTaggedUserIds != null && currentlyTaggedUserIds.contains(friend.getFriendId())) {
                    friendCheckBox.setSelected(true);
                }

                friendCheckboxes.add(friendCheckBox);
                taggedFriendsBox.getChildren().add(friendCheckBox);
            }
        }

        HBox btnBox = new HBox(14, saveBtn, cancelBtn);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        box.getChildren().addAll(
            titleLbl,
            titleField,
            contentArea,
            attachImgBtn,
            imagePreview,
            tagFriendsLabel,
            taggedFriendsBox,
            btnBox
        );

        Scene scene = new Scene(box);
        // Animation mở dialog
        box.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(320), box);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();

        dialog.setScene(scene);
        javafx.application.Platform.runLater(() -> dialog.centerOnScreen());
        dialog.showAndWait();
    }

    private HBox createFriendCard(Friend friend) {
        HBox friendCard = new HBox(12);
        friendCard.setPadding(new Insets(14, 24, 14, 24));
        friendCard.setStyle("-fx-background-color: #e0e7ff; -fx-background-radius: 14; -fx-effect: dropshadow(gaussian, #a5b4fc44, 4, 0.1, 0, 1);");
        friendCard.setAlignment(Pos.CENTER_LEFT);

        // Avatar circle with initial
        Circle avatar = new Circle(18, Color.web("#6d28d9"));
        Label initial = new Label(friend.getUsername().substring(0, 1).toUpperCase());
        initial.setTextFill(Color.WHITE);
        initial.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        StackPane avatarPane = new StackPane(avatar, initial);

        // Friend info
        VBox infoBox = new VBox(4);
        Label nameLabel = new Label(friend.getUsername());
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        nameLabel.setTextFill(Color.web("#312e81"));

        Label emailLabel = new Label(friend.getEmail());
        emailLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 12));
        emailLabel.setTextFill(Color.web("#6b7280"));

        infoBox.getChildren().addAll(nameLabel, emailLabel);

        // Spacer
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Remove friend button
        Button removeBtn = new Button("Xóa");
        removeBtn.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        removeBtn.setStyle(
            "-fx-background-color: #fca5a5;" +
            "-fx-text-fill: #444;" +
            "-fx-background-radius: 6;"
        );
        removeBtn.setOnMouseEntered(e -> removeBtn.setStyle(
            "-fx-background-color: #f87171;" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        removeBtn.setOnMouseExited(e -> removeBtn.setStyle(
            "-fx-background-color: #fca5a5;" +
            "-fx-text-fill: #444;" +
            "-fx-background-radius: 6;"
        ));
        removeBtn.setOnAction(e -> {
            Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDialog.setTitle("Xác nhận xóa");
            confirmDialog.setHeaderText("Bạn có chắc chắn muốn xóa " + friend.getUsername() + " khỏi danh sách bạn bè?");
            confirmDialog.showAndWait().ifPresent(result -> {
                if (result == ButtonType.OK) {
                    if (DatabaseManager.removeFriend(DatabaseManager.getCurrentUserId(), friend.getFriendId())) {
                        diaryListBox.getChildren().remove(friendCard);
                        Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Đã xóa bạn thành công!");
                        successAlert.showAndWait();
                    } else {
                        Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Lỗi khi xóa bạn!");
                        errorAlert.showAndWait();
                    }
                }
            });
        });

        friendCard.getChildren().addAll(avatarPane, infoBox, spacer, removeBtn);
        return friendCard;
    }

    private void showAddFriendDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Thêm bạn mới");

        VBox box = new VBox(22);
        box.setPadding(new Insets(36, 36, 32, 36));
        box.setAlignment(Pos.CENTER);
        box.setSpacing(18);
        box.setStyle(
            "-fx-background-radius: 22;" +
            "-fx-background-insets: 0;" +
            "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #ede9fe, #c7d2fe);" +
            "-fx-effect: dropshadow(gaussian, #a5b4fc88, 18, 0.3, 0, 4);"
        );

        Label titleLbl = new Label("Thêm bạn mới");
        titleLbl.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 26));
        titleLbl.setTextFill(Color.web("#6d28d9"));
        titleLbl.setStyle("-fx-effect: dropshadow(gaussian, #a5b4fc, 8, 0.2, 0, 2);");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Tên đăng nhập của bạn");
        usernameField.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
        usernameField.setPrefWidth(340);
        usernameField.setStyle(
            "-fx-background-radius: 12;" +
            "-fx-border-radius: 12;" +
            "-fx-border-color: #a5b4fc;" +
            "-fx-border-width: 1.2;" +
            "-fx-background-color: #fff;"
        );

        Button addBtn = new Button("Thêm");
        addBtn.setDefaultButton(true);
        addBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        addBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;");
        addBtn.setOnMouseEntered(e -> addBtn.setStyle("-fx-background-color: #7c3aed; -fx-text-fill: white; -fx-background-radius: 10;"));
        addBtn.setOnMouseExited(e -> addBtn.setStyle("-fx-background-color: #6d28d9; -fx-text-fill: white; -fx-background-radius: 10;"));
        addBtn.setOnAction(e -> {
            String username = usernameField.getText().trim();
            if (username.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Vui lòng nhập tên đăng nhập!");
                alert.showAndWait();
            } else {
                if (DatabaseManager.addFriend(DatabaseManager.getCurrentUserId(), username)) {
                    updateTab("Bạn bè"); // Refresh friends list
                    dialog.close();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Không tìm thấy người dùng hoặc đã là bạn!");
                    alert.showAndWait();
                }
            }
        });

        Button cancelBtn = new Button("Hủy");
        cancelBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        cancelBtn.setStyle("-fx-background-color: #e5e7eb; -fx-text-fill: #6d28d9; -fx-background-radius: 10;");
        cancelBtn.setOnMouseEntered(e -> cancelBtn.setStyle("-fx-background-color: #c7d2fe; -fx-text-fill: #232136; -fx-background-radius: 10;"));
        cancelBtn.setOnMouseExited(e -> cancelBtn.setStyle("-fx-background-color: #e5e7eb; -fx-text-fill: #6d28d9; -fx-background-radius: 10;"));
        cancelBtn.setOnAction(e -> dialog.close());

        HBox btnBox = new HBox(14, addBtn, cancelBtn);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        box.getChildren().addAll(titleLbl, usernameField, btnBox);

        Scene scene = new Scene(box);
        box.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(320), box);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();

        dialog.setScene(scene);
        javafx.application.Platform.runLater(() -> dialog.centerOnScreen());
        dialog.showAndWait();
    }

    private HBox createPotentialFriendCard(Friend friend) {
        HBox friendCard = new HBox(12);
        friendCard.setPadding(new Insets(14, 24, 14, 24));
        friendCard.setPrefHeight(60); // Explicitly set preferred height
        friendCard.setStyle("-fx-background-color: #f3f4f6; -fx-background-radius: 14; -fx-effect: dropshadow(gaussian, #a5b4fc44, 4, 0.1, 0, 1);");
        friendCard.setAlignment(Pos.CENTER_LEFT);

        // Avatar circle with initial
        Circle avatar = new Circle(18, Color.web("#6d28d9"));
        Label initial = new Label(friend.getUsername().substring(0, 1).toUpperCase());
        initial.setTextFill(Color.WHITE);
        initial.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        StackPane avatarPane = new StackPane(avatar, initial);

        // Friend info
        VBox infoBox = new VBox(4);
        Label nameLabel = new Label(friend.getUsername());
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        nameLabel.setTextFill(Color.web("#312e81"));

        Label emailLabel = new Label(friend.getEmail());
        emailLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 12));
        emailLabel.setTextFill(Color.web("#6b7280"));

        infoBox.getChildren().addAll(nameLabel, emailLabel);

        // Spacer
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Add friend button
        Button addBtn = new Button("Kết bạn");
        addBtn.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        addBtn.setStyle(
            "-fx-background-color: #6d28d9;" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        );
        addBtn.setOnMouseEntered(e -> addBtn.setStyle(
            "-fx-background-color: #7c3aed;" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        addBtn.setOnMouseExited(e -> addBtn.setStyle(
            "-fx-background-color: #6d28d9;" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        addBtn.setOnAction(e -> {
            if (DatabaseManager.addFriend(DatabaseManager.getCurrentUserId(), friend.getUsername())) {
                // Remove the card from potential friends list
                ((VBox) friendCard.getParent()).getChildren().remove(friendCard);
                // Refresh friends list
                updateTab("Bạn bè");
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Đã thêm bạn thành công!");
                successAlert.showAndWait();
            } else {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Lỗi khi thêm bạn!");
                errorAlert.showAndWait();
            }
        });

        friendCard.getChildren().addAll(avatarPane, infoBox, spacer, addBtn);
        return friendCard;
    }

    // Method to create a friend request card UI
    private HBox createFriendRequestCard(FriendRequest request) {
        HBox requestCard = new HBox(12);
        requestCard.setPadding(new Insets(14, 24, 14, 24));
        requestCard.setPrefHeight(60); // Explicitly set preferred height
        requestCard.setStyle("-fx-background-color: #e0e7ff; -fx-background-radius: 14; -fx-effect: dropshadow(gaussian, #a5b4fc44, 4, 0.1, 0, 1);");
        requestCard.setAlignment(Pos.CENTER_LEFT);

        // Avatar circle with initial
        Circle avatar = new Circle(18, Color.web("#6d28d9"));
        Label initial = new Label(request.getSenderUsername().substring(0, 1).toUpperCase());
        initial.setTextFill(Color.WHITE);
        initial.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        StackPane avatarPane = new StackPane(avatar, initial);

        // Sender info
        VBox infoBox = new VBox(4);
        Label nameLabel = new Label(request.getSenderUsername());
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        nameLabel.setTextFill(Color.web("#312e81"));

        Label emailLabel = new Label(request.getSenderEmail());
        emailLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 12));
        emailLabel.setTextFill(Color.web("#6b7280"));

        infoBox.getChildren().addAll(nameLabel, emailLabel);

        // Spacer
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Action buttons
        Button acceptBtn = new Button("Chấp nhận");
        acceptBtn.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        acceptBtn.setStyle(
            "-fx-background-color: #84cc16;" + // Green color
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        );
        acceptBtn.setOnMouseEntered(e -> acceptBtn.setStyle(
            "-fx-background-color: #a3e635;" + // Lighter green
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        acceptBtn.setOnMouseExited(e -> acceptBtn.setStyle(
            "-fx-background-color: #84cc16;" + // Green color
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        acceptBtn.setOnAction(e -> {
            if (DatabaseManager.acceptFriendRequest(request.getId())) {
                // Refresh friend requests and friends list
                updateTab("Bạn bè");
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Đã chấp nhận lời mời kết bạn!");
                successAlert.showAndWait();
            } else {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Lỗi khi chấp nhận lời mời kết bạn!");
                errorAlert.showAndWait();
            }
        });

        Button rejectBtn = new Button("Từ chối");
        rejectBtn.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        rejectBtn.setStyle(
            "-fx-background-color: #ef4444;" + // Red color
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        );
        rejectBtn.setOnMouseEntered(e -> rejectBtn.setStyle(
            "-fx-background-color: #f87171;" + // Lighter red
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        rejectBtn.setOnMouseExited(e -> rejectBtn.setStyle(
            "-fx-background-color: #ef4444;" + // Red color
            "-fx-text-fill: white;" +
            "-fx-background-radius: 6;"
        ));
        rejectBtn.setOnAction(e -> {
             if (DatabaseManager.rejectFriendRequest(request.getId())) {
                // Refresh friend requests list
                updateTab("Bạn bè");
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION, "Đã từ chối lời mời kết bạn!");
                successAlert.showAndWait();
            } else {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Lỗi khi từ chối lời mời kết bạn!");
                errorAlert.showAndWait();
            }
        });

        HBox buttonBox = new HBox(8, acceptBtn, rejectBtn); // Spacing between buttons

        requestCard.getChildren().addAll(avatarPane, infoBox, spacer, buttonBox);
        return requestCard;
    }
}