import java.util.List;

public interface DiaryService {
    List<DiaryEntry> getMyDiaries();
    List<DiaryEntry> getSharedDiaries();
    void addDiary(DiaryEntry entry);
    // Có thể bổ sung: updateDiary, deleteDiary, getDiaryById, v.v.
} 