import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.ScrollPane;

public class DiaryDetailView extends Stage {

    public DiaryDetailView(DiaryEntry entry) {
        this.initModality(Modality.APPLICATION_MODAL);
        this.setTitle("Chi tiết nhật ký");

        VBox root = new VBox(15);
        root.setPadding(new Insets(25));
        root.setAlignment(Pos.TOP_LEFT);
        root.setStyle("-fx-background-color: #00FFFF;"); // Changed background to white

        Label titleLabel = new Label(entry.getTitle());
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#000000"));
        titleLabel.setWrapText(true);

        Label dateLabel = new Label(entry.getDate());
        dateLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        dateLabel.setTextFill(Color.web("#000000"));

        ImageView imageView = null;
        if (entry.getImagePath() != null && !entry.getImagePath().isEmpty()) {
            Image image = new Image(entry.getImagePath());
            imageView = new ImageView(image);
            imageView.setFitWidth(600); // Adjust width as needed
            imageView.setPreserveRatio(true);
            imageView.setSmooth(true);
            imageView.setStyle("-fx-background-radius: 10;");
        }

        Label contentLabel = new Label(entry.getContent());
        contentLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
        contentLabel.setTextFill(Color.web("#444"));
        contentLabel.setWrapText(true);

        VBox contentBox = new VBox(10);
        contentBox.getChildren().addAll(titleLabel, dateLabel);
        if (imageView != null) {
            contentBox.getChildren().add(imageView);
        }
        contentBox.getChildren().add(contentLabel);

        ScrollPane scrollPane = new ScrollPane(contentBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        root.getChildren().add(scrollPane);
        VBox.setVgrow(scrollPane, Priority.ALWAYS);

        Scene scene = new Scene(root, 700, 600); // Adjust size as needed
        this.setScene(scene);
    }
} 