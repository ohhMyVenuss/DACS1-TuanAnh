import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

public class LoginView extends StackPane {
    public LoginView(Stage primaryStage) {
        setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #1c1c1c, #3a3a52);");
        VBox mainBox = new VBox(18);
        mainBox.setAlignment(Pos.CENTER);
        mainBox.setPadding(new Insets(30, 40, 30, 40));
        mainBox.setMaxWidth(400);
        mainBox.setStyle("-fx-background-radius: 20; -fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #232136, #45475a); -fx-effect: dropshadow(gaussian, #00000055, 20, 0.2, 0, 4);");

        // Close button
        Button closeBtn = new Button("×");
        closeBtn.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        closeBtn.setTextFill(Color.WHITE);
        closeBtn.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        closeBtn.setOnAction(e -> primaryStage.close());
        HBox closeBox = new HBox(closeBtn);
        closeBox.setAlignment(Pos.TOP_RIGHT);
        mainBox.getChildren().add(closeBox);

        Label title = new Label("Welcome Back");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.setTextFill(Color.WHITE);
        title.setAlignment(Pos.CENTER);
        Label subtitle = new Label("Sign in to continue");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        subtitle.setTextFill(Color.rgb(255,255,255,0.8));
        subtitle.setAlignment(Pos.CENTER);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setFont(Font.font("Arial", FontWeight.NORMAL, 15));
        usernameField.setMaxWidth(300);
        usernameField.setStyle("-fx-background-radius: 10; -fx-background-color: #e5e7eb; -fx-border-radius: 10; -fx-border-color: #a5b4fc; -fx-border-width: 1.2; -fx-padding: 8 12 8 12;");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setFont(Font.font("Arial", FontWeight.NORMAL, 15));
        passwordField.setMaxWidth(300);
        passwordField.setStyle("-fx-background-radius: 10; -fx-background-color: #e5e7eb; -fx-border-radius: 10; -fx-border-color: #a5b4fc; -fx-border-width: 1.2; -fx-padding: 8 12 8 12;");

        HBox optionsBox = new HBox();
        optionsBox.setAlignment(Pos.CENTER_LEFT);
        CheckBox rememberMe = new CheckBox("Remember me");
        rememberMe.setTextFill(Color.WHITE);
        rememberMe.setStyle("-fx-cursor: hand;");
        Button forgotBtn = new Button("Forgot password?");
        forgotBtn.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        forgotBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #bfaee0; -fx-cursor: hand;");
        optionsBox.getChildren().addAll(rememberMe, new Region(), forgotBtn);
        HBox.setHgrow(optionsBox.getChildren().get(1), Priority.ALWAYS);

        Button loginBtn = new Button("Login");
        loginBtn.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        loginBtn.setStyle("-fx-background-radius: 10; -fx-background-color: #6d28d9; -fx-text-fill: white; -fx-cursor: hand;");
        loginBtn.setMaxWidth(300);
        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle("-fx-background-radius: 10; -fx-background-color: #a5b4fc; -fx-text-fill: #232136; -fx-cursor: hand;"));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle("-fx-background-radius: 10; -fx-background-color: #6d28d9; -fx-text-fill: white; -fx-cursor: hand;"));

        Label errorLabel = new Label();
        errorLabel.setTextFill(Color.web("#ff6b6b"));
        errorLabel.setFont(Font.font("Arial", FontWeight.BOLD, 13));

        loginBtn.setOnAction(e -> {
            String user = usernameField.getText();
            String pass = passwordField.getText();
            // Validate user against the database
            int userId = DatabaseManager.validateUser(user, pass);
            if (userId != -1) {
                // Đăng nhập thành công, chuyển sang màn hình chính
                DiaryMainView diaryMainView = new DiaryMainView();
                Scene diaryScene = new Scene(diaryMainView, 1200, 800);
                primaryStage.setScene(diaryScene);
                primaryStage.setTitle("Nhật ký");
            } else {
                errorLabel.setText("Tên đăng nhập hoặc mật khẩu không đúng!");
            }
        });

        HBox registerBox = new HBox(6);
        registerBox.setAlignment(Pos.CENTER);
        Label noAccount = new Label("Don't have an account?");
        noAccount.setTextFill(Color.LIGHTGRAY);
        Button signUpBtn = new Button("Sign Up");
        signUpBtn.setFont(Font.font("Arial", FontWeight.BOLD, 13));
        signUpBtn.setStyle("-fx-background-radius: 8; -fx-background-color: #ede9fe; -fx-text-fill: #6d28d9; -fx-cursor: hand;");
        signUpBtn.setOnMouseEntered(e -> signUpBtn.setStyle("-fx-background-radius: 8; -fx-background-color: #c7d2fe; -fx-text-fill: #232136; -fx-cursor: hand;"));
        signUpBtn.setOnMouseExited(e -> signUpBtn.setStyle("-fx-background-radius: 8; -fx-background-color: #ede9fe; -fx-text-fill: #6d28d9; -fx-cursor: hand;"));
        signUpBtn.setOnAction(e -> {
            Stage currentStage = (Stage) getScene().getWindow();
            SignUpView signUpView = new SignUpView(currentStage);
            Scene signUpScene = new Scene(signUpView, 400, 500);
            currentStage.setScene(signUpScene);
            currentStage.setTitle("Sign Up");
            currentStage.show();
            javafx.application.Platform.runLater(() -> currentStage.centerOnScreen());
        });
        registerBox.getChildren().addAll(noAccount, signUpBtn);

        mainBox.getChildren().addAll(title, subtitle, usernameField, passwordField, optionsBox, loginBtn, errorLabel, registerBox);
        setAlignment(Pos.CENTER);
        getChildren().add(mainBox);
        // Fade in effect
        mainBox.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(600), mainBox);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();
    }
} 